# -*- coding: utf-8 -*-

# --- Importy systemowe i Kodi ---
import sys
import os
import re
import base64
import json
import html
from urllib.parse import urlencode, unquote, parse_qs, quote_plus, urljoin

# Importy z API Kodi
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# --- Uchwyty do API Kodi ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_HANDLE = int(sys.argv[1])
ADDON_URL = sys.argv[0]

# --- Prawidłowe dodanie ścieżki do bibliotek ---
sys.path.insert(0, os.path.join(ADDON_PATH, 'lib'))
import cloudscraper
from bs4 import BeautifulSoup

# --- Stałe konfiguracyjne ---
BASE_URL = "https://ritsatv.ru"
HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0', 'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3'}

# --- Słownik z tłumaczeniami kategorii ---
CATEGORY_TRANSLATIONS = {
    'ГЛАВНАЯ': 'GŁÓWNA', 'ИНФОРМАЦИОННЫЕ': 'INFORMACYJNE',
    'МУЗЫКАЛЬНЫЕ ТЕЛЕКАНАЛЫ': 'KANAŁY MUZYCZNE', 'КИНОКАНАЛЫ': 'KANAŁY FILMOWE',
    'СПОРТИВНЫЕ': 'SPORTOWE', 'АБХАЗИЯ - ТВ': 'ABCHAZJA - TV',
    'РЕГИОНАЛЬНОЕ ТВ': 'TV REGIONALNA', 'ПОЗНАВАТЕЛЬНЫЕ': 'POZNAWCZE',
    'ДЕТСКИЕ КАНАЛЫ': 'DLA DZIECI', 'РАДИО СТАНЦИИ': 'STACJE RADIOWE',
    'ЗАРУБЕЖНЫЕ': 'ZAGRANICZNE', 'TÜRK TV KANALLARI': 'TURECKIE KANAŁY TV',
    'ВИДЕО КЛИПЫ': 'TELEDYSKI', 'МУЗЫКА RELAX': 'MUZYKA RELAKSACYJNA',
    'КИНОТЕАТР ОНЛАЙН': 'KINO ONLINE', 'AI CHAT': 'AI CZAT'
}

# --- Inicjalizacja sesji cloudscraper ---
scraper = None
try:
    scraper = cloudscraper.create_scraper(browser={'browser': 'firefox', 'platform': 'windows', 'mobile': False})
    scraper.headers.update(HEADERS)
    xbmc.log(f"[{ADDON_ID}] Globalna sesja scrapera pomyślnie zainicjowana.", xbmc.LOGINFO)
except Exception as e:
    xbmc.log(f"[{ADDON_ID}] KRYTYCZNY BŁĄD: Nie można zainicjować cloudscraper: {e}", xbmc.LOGERROR)


def log_msg(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_ID}] {msg}", level=level)

# === Logika pobierania danych ===

def get_video_list_from_url(url):
    log_msg(f"Pobieranie listy filmów z URL: {url}")
    try:
        response = scraper.get(url, timeout=15)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        videos = []
        for item in soup.find_all('div', class_='owl-item'):
            title_container = item.find('div', class_='main-sliders-title')
            if not title_container: continue
            link_tag = title_container.find('a')
            img_tag = item.find('img')
            if link_tag and link_tag.has_attr('href') and img_tag:
                page_url = link_tag['href']
                title = link_tag.get_text(strip=True)
                icon_src = img_tag.get('src')
                icon = urljoin(BASE_URL, icon_src) if icon_src else ''
                if title and page_url:
                    videos.append({'title': title, 'page_url': page_url, 'icon': icon})
        log_msg(f"Znaleziono {len(videos)} materiałów wideo.")
        
        next_page_url = None
        navigation_div = soup.find('div', class_='navigation')
        if navigation_div:
            # Poprawka: używamy 'string' zamiast przestarzałego 'text'
            next_page_link = navigation_div.find('a', string=re.compile(r'»'))
            if next_page_link and next_page_link.has_attr('href'):
                href = next_page_link['href']
                next_page_url = urljoin(BASE_URL, href)
                log_msg(f"Znaleziono link do następnej strony: {next_page_url}")

        return videos, next_page_url
    except Exception as e:
        log_msg(f"Błąd w get_video_list_from_url: {e}", level=xbmc.LOGERROR)
        return [], None

def _resolve_okru(okru_url, referer):
    log_msg(f"Wykryto odtwarzacz ok.ru. Próba ekstrakcji z: {okru_url}")
    try:
        response_ok = scraper.get(okru_url, headers={'Referer': referer}, timeout=20)
        response_ok.raise_for_status()
        match_json = re.search(r'data-options=["\']([^"\']+)', response_ok.text) or \
                     re.search(r'OKVideoPlayer\([^,]+,\s*[^,]+,\s*({.+?})\);', response_ok.text, re.DOTALL)
        if not match_json: return None, None
        player_data = json.loads(html.unescape(match_json.group(1)))
        metadata = json.loads(player_data.get('flashvars', {}).get('metadata', '{}'))
        stream_url = metadata.get('hlsMasterPlaylistUrl') or metadata.get('hlsPlaybackMasterPlaylistUrl')
        if stream_url: return stream_url, 'hls'
        stream_url = metadata.get('liveDashManifestUrl') or metadata.get('livePlaybackDashManifestUrl')
        if stream_url: return stream_url, 'mpd'
        return None, None
    except Exception as e:
        log_msg(f"Błąd podczas parsowania ok.ru: {e}", level=xbmc.LOGERROR)
        return None, None
        
def _resolve_ritsatv(iframe1_url):
    log_msg(f"Analiza wewnętrznego odtwarzacza ritsatv: {iframe1_url}")
    try:
        response1 = scraper.get(iframe1_url, timeout=15)
        response1.raise_for_status()
        content1 = response1.text
        final_content = content1

        nested_match = re.search(r"iframe\.src\s*=\s*['\"]([^'\"]+\.html)", content1)
        if nested_match:
            nested_path = nested_match.group(1)
            iframe2_url = urljoin(BASE_URL, nested_path)
            log_msg(f"KROK 2 SUKCES: Znaleziono dynamiczny iframe: {iframe2_url}.")
            response2 = scraper.get(iframe2_url, timeout=15)
            response2.raise_for_status()
            final_content = response2.text
        else:
            log_msg("KROK 2 INFO: Brak zagnieżdżonego iframe'a.")

        log_msg("KROK 3: Próba wyodrębnienia linku z finalnej zawartości.")
        
        file_match = re.search(r'(?:file|source)\s*:\s*["\'](.*?)["\']', final_content)
        if file_match:
            content = file_match.group(1).strip()
            
            if '[' in content and ']' in content:
                url_match = re.search(r'(https?://[^\s,\'"]+)', content)
                if url_match: return url_match.group(1), 'hls'
                
            if content.startswith('#2'):
                try: return base64.b64decode(content[2:] + '==').decode('utf-8'), 'hls'
                except: pass
            
            if content.startswith('L2Vj'):
                try:
                    url = base64.b64decode(content + '==').decode('utf-8')
                    return urljoin('https://an.svetacdn.in/', url), 'hls'
                except: pass

            try:
                url = base64.b64decode(content[::-1] + '==').decode('utf-8')
                return urljoin('https:', url), 'hls'
            except: pass

        log_msg("KROK 3 BŁĄD: Nie udało się wyodrębnić linku.", level=xbmc.LOGERROR)
        return None, None
    except Exception as e:
        log_msg(f"Błąd w _resolve_ritsatv: {e}", level=xbmc.LOGERROR)
        return None, None

def get_stream_url_from_page(video_page_url):
    log_msg(f"Analiza strony z wideo: {video_page_url}")
    try:
        response_main = scraper.get(video_page_url, timeout=15)
        response_main.raise_for_status()
        soup_main = BeautifulSoup(response_main.text, 'html.parser')

        iframe_tag = soup_main.find('iframe')
        if not iframe_tag or not iframe_tag.has_attr('src'):
            log_msg("KROK 1 BŁĄD: Nie znaleziono iframe'a.", level=xbmc.LOGERROR)
            return None, None
            
        iframe_url = urljoin(BASE_URL, iframe_tag['src'])
        log_msg(f"KROK 1 SUKCES: Znaleziono iframe: {iframe_url}")
        
        # --- PRZYWRÓCONA I POPRAWIONA LOGIKA ---
        if 'PLAYER/playerT.html' in iframe_url:
            parsed_url = parse_qs(iframe_url.split('?')[-1])
            file_param = parsed_url.get('file', [None])[0]
            if file_param:
                urls = re.split(r'\s+or\s+', file_param, flags=re.IGNORECASE)
                log_msg(f"Sukces! Znaleziono link z parametru URL: {urls[0].strip()}")
                return urls[0].strip(), 'hls'
        
        if 'ok.ru/videoembed' in iframe_url:
            return _resolve_okru(iframe_url, video_page_url)
        else:
            return _resolve_ritsatv(iframe_url)
            
    except Exception as e:
        log_msg(f"Błąd w get_stream_url_from_page: {e}", level=xbmc.LOGERROR)
        return None, None

def list_categories():
    log_msg("Akcja: list_categories - tworzenie menu głównego.")
    xbmcplugin.setPluginCategory(ADDON_HANDLE, 'Główne Kategorie')
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    try:
        response = scraper.get(BASE_URL, timeout=15)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        menu_list = soup.find('ul', class_='top-menu')
        if not menu_list:
            log_msg("Nie znaleziono menu z kategoriami...", level=xbmc.LOGERROR)
            return
        for item in menu_list.find_all('a'):
            original_title = item.get_text(strip=True)
            href = item.get('href')
            translated_title = CATEGORY_TRANSLATIONS.get(original_title.upper(), original_title)
            if original_title and href and href != '/' and 'javascript' not in href:
                category_url = urljoin(BASE_URL, href)
                list_item = xbmcgui.ListItem(label=translated_title)
                fanart = ADDON.getAddonInfo('fanart') or ''
                list_item.setArt({'fanart': fanart})
                url = f"{ADDON_URL}?action=list_videos&category_url={quote_plus(category_url)}"
                xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=list_item, isFolder=True)
    except Exception as e:
        log_msg(f"Błąd w list_categories: {e}", level=xbmc.LOGERROR)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_videos(category_url):
    log_msg(f"Akcja: list_videos - URL: {category_url}")
    xbmcplugin.setPluginCategory(ADDON_HANDLE, 'Materiały Wideo')
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    videos, next_page_url = get_video_list_from_url(category_url)
    for video in videos:
        list_item = xbmcgui.ListItem(label=video['title'])
        list_item.setInfo('video', {'title': video['title'], 'mediatype': 'video'})
        fanart = ADDON.getAddonInfo('fanart') or ''
        list_item.setArt({'thumb': video['icon'], 'icon': video['icon'], 'fanart': fanart})
        list_item.setProperty('IsPlayable', 'true')
        url = f"{ADDON_URL}?action=play&page_url={quote_plus(video['page_url'])}"
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=list_item, isFolder=False)
    if next_page_url:
        list_item = xbmcgui.ListItem(label=">> Następna strona")
        url = f"{ADDON_URL}?action=list_videos&category_url={quote_plus(next_page_url)}"
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_video(page_url):
    log_msg(f"Akcja: play_video - strona: {page_url}")
    pDialog = xbmcgui.DialogProgress()
    pDialog.create(ADDON_NAME, "Pobieranie linku...")
    pDialog.update(50)
    stream_url, manifest_type = get_stream_url_from_page(page_url)
    pDialog.close()
    
    if stream_url:
        final_referer = page_url
        if 'ok.ru' in stream_url:
            final_referer = stream_url.split('|')[0] 

        final_headers = {'User-Agent': HEADERS['User-Agent'], 'Referer': final_referer}
        
        play_item = xbmcgui.ListItem(path=f"{stream_url}|{urlencode(final_headers)}")
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.manifest_type', manifest_type or 'hls')
        
        if manifest_type == 'hls':
            play_item.setMimeType('application/vnd.apple.mpegurl')
        elif manifest_type == 'mpd':
            play_item.setMimeType('application/dash+xml')
        
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=play_item)
    else:
        log_msg("Odtwarzanie nie powiodło się, nie znaleziono linku.", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, "Nie udało się pobrać linku do odtworzenia.")

def router(paramstring):
    if not scraper:
        xbmcgui.Dialog().ok(ADDON_NAME, "Krytyczny błąd: Nie można zainicjować sesji sieciowej.")
        return
        
    params = parse_qs(unquote(paramstring))
    action = params.get('action', [None])[0]
    log_msg("="*40)
    log_msg(f"Wtyczka uruchomiona. Akcja: '{action}', Parametry: {params}")
    log_msg("="*40)
    if action is None:
        list_categories()
    elif action == 'list_videos':
        category_url = params.get('category_url', [None])[0]
        if category_url:
            list_videos(category_url)
    elif action == 'play':
        page_url = params.get('page_url', [None])[0]
        if page_url:
            play_video(page_url)

if __name__ == '__main__':
    router(sys.argv[2][1:])