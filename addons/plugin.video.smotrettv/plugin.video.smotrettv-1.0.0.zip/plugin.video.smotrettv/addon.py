# -*- coding: utf-8 -*-

import sys, os, json, re, html
from urllib.parse import urlencode, parse_qsl, urljoin

import xbmc, xbmcgui, xbmcplugin, xbmcaddon

# Konfiguracja ścieżek
ADDON_PATH = xbmcaddon.Addon().getAddonInfo('path')
sys.path.insert(0, os.path.join(ADDON_PATH, 'lib'))
import cloudscraper

# Ustawienia globalne
BASE_URL, ADDON_HANDLE, PARAMS = sys.argv[0], int(sys.argv[1]), dict(parse_qsl(sys.argv[2][1:]))
ADDON, ADDON_NAME, PATH = xbmcaddon.Addon(), xbmcaddon.Addon().getAddonInfo('name'), xbmcaddon.Addon().getAddonInfo('path')
FANART, ICON = f'{PATH}/fanart.png', f'{PATH}/icon.png'
HOME_URL = 'https://smotret.tv/'

# Sesja
scraper = None
try:
    log_msg_prefix = f"[{ADDON_NAME}]"
    def log(msg, level=xbmc.LOGINFO):
        xbmc.log(f"{log_msg_prefix} {msg}", level)

    scraper = cloudscraper.create_scraper(browser={ 'browser': 'firefox', 'platform': 'windows', 'mobile': False })
    scraper.headers.update({
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3'
    })
    log("Globalna sesja scrapera pomyślnie zainicjowana.")
except Exception as e:
    xbmc.log(f"[{ADDON_NAME}] KRYTYCZNY BŁĄD: Nie można zainicjować cloudscraper: {e}", xbmc.LOGERROR)

# Funkcje pomocnicze
def build_url(query): return f'{BASE_URL}?{urlencode(query)}'

def add_item(url, name, image, mode, is_folder=False, is_playable=False, info=None, extra_params=None):
    li = xbmcgui.ListItem(label=name)
    if not info: info = {'title': name, 'mediatype': 'video'}
    li.setInfo('video', info)
    li.setProperty("IsPlayable", 'true' if is_playable else 'false')
    li.setArt({'thumb': image, 'icon': image, 'poster': image, 'fanart': FANART})
    params = {'mode': mode, 'url': url, 'title': name}
    if extra_params: params.update(extra_params)
    built_url = build_url(params)
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=built_url, listitem=li, isFolder=is_folder)

# Główne widoki
def main_menu():
    categories = [{'slug': '', 'name': '[B]Wszystkie kanały[/B]'}, {'slug': 'music/', 'name': 'Muzyczne'}, {'slug': 'sport/', 'name': 'Sportowe'}, {'slug': 'news/', 'name': 'Informacyjne'}, {'slug': 'detskie/', 'name': 'Dziecięce'}, {'slug': 'christian/', 'name': 'Religijne'}, {'slug': 'razvlekatelnye/', 'name': 'Rozrywkowe'}, {'slug': 'poznavatelnye/', 'name': 'Poznawcze'}, {'slug': 'region/', 'name': 'Regionalne'}, {'slug': 'relax/', 'name': 'Relaksacyjne'}]
    for category in categories:
        add_item(category['slug'], category['name'], ICON, 'list_channels', is_folder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_channels(category_path):
    target_url = urljoin(HOME_URL, category_path)
    log(f"Pobieranie listy kanałów z {target_url}")
    try:
        response = scraper.get(target_url, headers={'Referer': HOME_URL}, timeout=30)
        response.raise_for_status()
    except Exception as e:
        log(f"Błąd pobierania strony kategorii: {e}", xbmc.LOGERROR)
        return xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
    
    matches = re.findall(r'<li\s+data-channel-id="([^"]+)"[^>]*>.*?<img[^>]+data-src="([^"]+)"[^>]*>.*?<span[^>]+class="tv_channel_name"[^>]*>([^<]+)</span>', response.text, re.DOTALL)
    for channel_id, logo_path, name in matches:
        add_item(channel_id, name.strip(), urljoin(HOME_URL, logo_path), 'play_stream', is_playable=True, extra_params={'category': category_path})
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_stream(channel_id):
    category_path = PARAMS.get('category', '')
    
    try:
        channel_page_url = urljoin(HOME_URL, category_path + channel_id)
        log(f"Krok 1: Pobieranie strony kanału: {channel_page_url}")
        response_channel = scraper.get(channel_page_url, headers={'Referer': urljoin(HOME_URL, category_path)}, timeout=20)
        response_channel.raise_for_status()
        
        iframe_page_content = response_channel.text
        iframe_referer = channel_page_url

        match_iframe_src = re.search(r'<iframe[^>]+src=["\']([^"\']+/iframes/[^"\']+)["\']', iframe_page_content)
        if match_iframe_src:
            iframe_src_url = urljoin(HOME_URL, match_iframe_src.group(1))
            log(f"Krok 2: Pobieranie zawartości ramki pośredniej: {iframe_src_url}")
            response_iframe = scraper.get(iframe_src_url, headers={'Referer': iframe_referer}, timeout=20)
            response_iframe.raise_for_status()
            iframe_page_content = response_iframe.text
            iframe_referer = iframe_src_url
        
        stream_url = None
        manifest_type = 'hls'
        final_referer = iframe_referer
        
        match_ok_iframe = re.search(r'<iframe[^>]+src=["\'](https?://ok\.ru/videoembed/[^"\']+)["\']', iframe_page_content)
        match_vk_iframe = re.search(r'<iframe[^>]+src=["\'](https?://(?:vk\.com|vkvideo\.ru)/video_ext\.php[^"\']+)["\']', iframe_page_content)
        
        if match_ok_iframe:
            log("Wykryto źródło: ok.ru")
            embed_url = html.unescape(match_ok_iframe.group(1))
            final_referer = embed_url
            response_ok = scraper.get(embed_url, headers={'Referer': iframe_referer}, timeout=20)
            match_json = re.search(r'data-options=["\']([^"\']+)', response_ok.text) or re.search(r'OKVideoPlayer\([^,]+,\s*[^,]+,\s*({.+?})\);', response_ok.text, re.DOTALL)
            player_data = json.loads(html.unescape(match_json.group(1)))
            metadata = json.loads(player_data.get('flashvars', {}).get('metadata', '{}'))
            stream_url = metadata.get('hlsMasterPlaylistUrl') or metadata.get('hlsPlaybackMasterPlaylistUrl')
            if not stream_url:
                stream_url = metadata.get('liveDashManifestUrl') or metadata.get('livePlaybackDashManifestUrl')
                manifest_type = 'mpd'
        
        elif match_vk_iframe:
            log("Wykryto źródło: vk.com")
            embed_url = html.unescape(match_vk_iframe.group(1))
            final_referer = embed_url
            response_vk = scraper.get(embed_url, headers={'Referer': iframe_referer}, timeout=20)
            
            match_params = re.search(r'var\s+playerParams\s*=\s*({.+?});', response_vk.text, re.DOTALL)
            if match_params:
                params_data = json.loads(match_params.group(1))
                player_params = params_data.get('params', [{}])[0]
                stream_url = player_params.get('hls_live')
                if not stream_url:
                    stream_url = player_params.get('dash_live')
                    manifest_type = 'mpd'

        else:
            log("Nie wykryto znanego odtwarzacza, szukam bezpośredniego linku .m3u8")
            match_m3u8 = re.search(r'["\'](https?://[^\'"\s]+\.m3u8[^\'"\s]*)["\']', iframe_page_content)
            if match_m3u8:
                stream_url = match_m3u8.group(1)

        if not stream_url: raise ValueError("Nie udało się znaleźć żadnego linku do strumienia.")

        log(f"SUKCES! Ostateczny link do strumienia ({manifest_type}): {stream_url}")
        
        li = xbmcgui.ListItem(path=stream_url)
        final_headers = {'User-Agent': scraper.headers['User-Agent'], 'Referer': final_referer}
        li.setPath(f"{stream_url}|{urlencode(final_headers)}")

        li.setProperty('inputstream', 'inputstream.adaptive')
        if manifest_type: li.setProperty('inputstream.adaptive.manifest_type', manifest_type)
        if manifest_type == 'hls': li.setMimeType('application/vnd.apple.mpegurl')
        elif manifest_type == 'mpd': li.setMimeType('application/dash+xml')

        li.setInfo('video', {'title': PARAMS.get('title', channel_id)})
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=li)

    except Exception as e:
        log(f"Finalny błąd pobierania strumienia: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Błąd odtwarzania", "Nie udało się pobrać linku.")
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())

def router():
    if not scraper: return
    mode, url = PARAMS.get('mode'), PARAMS.get('url')
    if mode is None: main_menu()
    elif mode == 'list_channels': list_channels(url)
    elif mode == 'play_stream': play_stream(url)

if __name__ == '__main__':
    router()