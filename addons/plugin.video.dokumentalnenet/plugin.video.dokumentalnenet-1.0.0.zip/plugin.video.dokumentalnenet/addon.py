# -*- coding: UTF-8 -*-
import sys
import re
import html

from urllib.parse import urlencode, parse_qsl, unquote_plus
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import requests
import json
from bs4 import BeautifulSoup


# --- Inicjalizacja ---
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(unquote_plus(sys.argv[2][1:])))
addon = xbmcaddon.Addon(id='plugin.video.dokumentalnenet')

# --- Ścieżki i Zmienne Globalne ---
PATH = addon.getAddonInfo('path')
RESOURCES = PATH + '/resources/'
FANART = RESOURCES + '../fanart.png'
ICON = RESOURCES + '../icon.png'
api_url_base = 'https://dokumentalne.net/wp-json/wp/v2/'
main_url = 'https://dokumentalne.net'
sess = requests.Session()
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'}
CATEGORY_ID_HD = 35

# --- Funkcje Pomocnicze ---
def log_message(message, level=xbmc.LOGINFO):
    xbmc.log(f"[DOKU.NET-API] {message}", level=level)

def build_url(query):
    clean_query = {k: v for k, v in query.items() if v is not None and v != '' and v != 'None'}
    return f"{base_url}?{urlencode(clean_query, doseq=True)}"

# --- Funkcje Tworzenia List ---
def add_item(mode, name, url=None, image=ICON, folder=False, is_playable=False, plot=None, **kwargs):
    list_item = xbmcgui.ListItem(label=name)
    video_info = list_item.getVideoInfoTag()
    video_info.setTitle(name)
    video_info.setPlot(plot if plot else name)
    video_info.setMediaType('video')
    if is_playable:
        list_item.setProperty("IsPlayable", 'true')
    list_item.setArt({'thumb': image, 'poster': image, 'banner': FANART, 'icon': image, 'fanart': FANART})
    query = {'mode': mode, 'url': url, 'name': name, 'image': image, 'plot': plot}
    query.update(kwargs)
    final_url = build_url(query)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=final_url, listitem=list_item, isFolder=folder)

def home():
    log_message("Wyświetlanie menu głównego.")
    # Te trzy pozycje prowadzą do tej samej, niefiltrowanej listy filmów
    add_item(mode='list_films', name='Strona główna', folder=True)
    add_item(mode='list_films', name='Najnowsze filmy', folder=True)
    add_item(mode='list_films', name='Wszystkie filmy', folder=True)

    # To są pozycje z filtrowaniem
    add_item(mode='list_categories', name='Kategorie', folder=True)
    add_item(mode='list_films', name='Filmy HD', category_id=CATEGORY_ID_HD, folder=True)
    
    # Wyszukiwarka
    add_item(mode='search', name='[B][COLOR violet]Szukaj[/COLOR][/B]', folder=True)
    
    xbmcplugin.setPluginCategory(addon_handle, "Strona Główna")
    xbmcplugin.endOfDirectory(addon_handle)

def list_films(category_id=None, search_query=None, page='1'):
    log_message(f"Listowanie filmów z API. Kategoria: {category_id}, Szukane: {search_query}, Strona: {page}")

    api_params = {'page': page, 'per_page': 10, '_embed': ''}
    if category_id and category_id != 'None':
        api_params['categories'] = category_id
    if search_query and search_query != 'None':
        api_params['search'] = search_query

    try:
        response = sess.get(api_url_base + 'posts', params=api_params, headers=headers, timeout=15)
        response.raise_for_status()
        posts = response.json()
        if isinstance(posts, dict) and posts.get('code'):
             log_message(f"API zwróciło błąd: {posts.get('message')}", level=xbmc.LOGERROR)
             posts = []
    except (requests.exceptions.RequestException, json.JSONDecodeError) as e:
        log_message(f"BŁĄD SIECI lub JSON przy zapytaniu do API: {e}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Błąd API', 'Nie można pobrać danych ze strony.', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(addon_handle); return

    if not posts:
        xbmcgui.Dialog().notification('Brak wyników', 'Nie znaleziono filmów.', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(addon_handle); return
    
    for post in posts:
        title = html.unescape(post.get('title', {}).get('rendered', 'Brak tytułu'))
        link_to_page = post.get('link')
        plot_raw = post.get('excerpt', {}).get('rendered', '')
        plot = html.unescape(re.sub('<[^<]+?>', '', plot_raw)).strip()
        image = ICON
        if '_embedded' in post and 'wp:featuredmedia' in post['_embedded']:
            image = post['_embedded']['wp:featuredmedia'][0].get('source_url', ICON)
        else:
            image = post.get('jetpack_featured_media_url', ICON)
        
        add_item(mode='play_film', name=title, url=link_to_page, image=image, is_playable=True, plot=plot, folder=False)

    total_pages = int(response.headers.get('X-WP-TotalPages', 0))
    current_page = int(page)
    if current_page < total_pages:
        add_item(mode='list_films', name='[B]Następna strona >>[/B]', category_id=category_id, search_query=search_query, page=str(current_page + 1), folder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def list_categories():
    log_message("Pobieranie kategorii z API.")
    try:
        response = sess.get(api_url_base + 'categories', params={'per_page': 100, 'orderby': 'name', 'order': 'asc'}, headers=headers, timeout=15)
        response.raise_for_status()
        categories = response.json()
    except (requests.exceptions.RequestException, json.JSONDecodeError) as e:
        log_message(f"BŁĄD SIECI lub JSON przy pobieraniu kategorii z API: {e}", level=xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(addon_handle); return

    for cat in categories:
        # 'Filmy HD' to teraz kategoria, więc ukrywamy ją tutaj, bo ma swoje miejsce w menu głównym
        if cat['slug'] in ['bez-kategorii', 'uncategorized', 'wszystkie-filmy', 'hd-filmy'] or cat['count'] == 0:
            continue
        add_item(mode='list_films', name=cat['name'], category_id=cat['id'], folder=True)
    
    xbmcplugin.setPluginCategory(addon_handle, "Kategorie")
    xbmcplugin.endOfDirectory(addon_handle)

def play_film(url, name, image, plot):
    log_message(f"Odtwarzanie: '{name}' ze strony: {url}")
    progress = xbmcgui.DialogProgress()
    progress.create("dokumentalne.net", "Przygotowuję odtwarzanie...")
    
    try:
        response = sess.get(url, headers=headers, timeout=15)
        response.raise_for_status()
        html_content = response.text
    except Exception as e:
        log_message(f"Nie udało się pobrać strony filmu: {e}", level=xbmc.LOGERROR)
        progress.close()
        xbmcgui.Dialog().notification('Błąd', 'Nie udało się wczytać strony filmu.', xbmcgui.NOTIFICATION_ERROR)
        return

    progress.update(50, "Wyszukuję link do wideo...")
    soup = BeautifulSoup(html_content, 'html.parser')
    player_container = soup.find('div', class_='player-content') or soup.find('div', id='player-embed')
    if not player_container or not (iframe := player_container.find('iframe')) or not (source_url := iframe.get('src')):
        progress.close()
        xbmcgui.Dialog().notification('Błąd', 'Nie znaleziono źródła wideo na stronie.', xbmcgui.NOTIFICATION_ERROR)
        return
    
    source_url = 'https:' + source_url if source_url.startswith('//') else source_url
    
    try:
        import resolveurl
        progress.update(75, "Rozwiązuję adres z ResolveURL...")
        resolved_url = resolveurl.resolve(source_url)
        progress.close()
        if resolved_url:
            list_item = xbmcgui.ListItem(path=resolved_url)
            video_info = list_item.getVideoInfoTag()
            video_info.setTitle(name)
            video_info.setPlot(plot)
            list_item.setArt({'thumb': image, 'poster': image, 'fanart': FANART})
            xbmcplugin.setResolvedUrl(addon_handle, True, list_item)
        else:
            raise ValueError("ResolveURL zwrócił pusty link.")
    except Exception as e:
        progress.close()
        log_message(f"Błąd ResolveURL: {e}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Błąd ResolveURL', "Nie udało się rozwiązać linku wideo.", xbmcgui.NOTIFICATION_ERROR)

def search():
    keyboard = xbmc.Keyboard('', 'Szukaj filmu')
    keyboard.doModal()
    if keyboard.isConfirmed() and (query_text := keyboard.getText()):
        list_films(search_query=query_text)

def router():
    mode = params.get('mode')
    log_message(f"Router: {params}")

    if mode is None: home()
    elif mode == 'list_films': list_films(params.get('category_id'), params.get('search_query'), params.get('page', '1'))
    elif mode == 'list_categories': list_categories()
    elif mode == 'play_film': play_film(params.get('url'), params.get('name'), params.get('image'), params.get('plot'))
    elif mode == 'search': search()

if __name__ == '__main__':
    router()