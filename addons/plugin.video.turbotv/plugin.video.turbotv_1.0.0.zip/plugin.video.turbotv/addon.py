# -*- coding: utf-8 -*-
import sys
import os
import re
from urllib.parse import urlencode, parse_qsl
import requests
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmcaddon

# --- Konfiguracja wtyczki ---
ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
ADDON_PATH = ADDON.getAddonInfo('path')
BASE_URL = "https://turbotv.cc"
LOGIN_URL = f"{BASE_URL}/pl/login"

FANART_PATH = os.path.join(ADDON_PATH, 'fanart.png')

SESSION = requests.Session()
SESSION.headers.update({
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
    'Referer': BASE_URL
})

def perform_login():
    """
    Wykonuje logowanie. Pokazuje powiadomienie tylko przy pierwszym udanym logowaniu
    lub po zmianie danych.
    """
    email = ADDON.getSetting('email')
    password = ADDON.getSetting('password')

    if not email or not password:
        return True # Działaj jako gość

    show_notification = ADDON.getSetting('show_login_notification') == 'true'
    current_fingerprint = f"{email}:{password}"
    last_fingerprint = ADDON.getSetting('last_login_fingerprint')

    # Logujemy się za każdym razem, ale powiadomienie pokazujemy tylko, gdy trzeba
    try:
        login_page_response = SESSION.get(LOGIN_URL)
        login_page_response.raise_for_status()
        
        soup = BeautifulSoup(login_page_response.text, 'html.parser')
        token = soup.find('input', {'name': '_token'})['value']

        payload = {'_token': token, 'email': email, 'password': password}
        login_response = SESSION.post(LOGIN_URL, data=payload, allow_redirects=True)
        login_response.raise_for_status()

        if "Błędne dane logowania" in login_response.text or login_response.url == LOGIN_URL:
            if show_notification and last_fingerprint: # Pokaż błąd, jeśli wcześniej byliśmy zalogowani
                xbmcgui.Dialog().notification("Logowanie nieudane", "Sprawdź e-mail i hasło", xbmcgui.NOTIFICATION_ERROR, 5000)
            ADDON.setSetting('last_login_fingerprint', '') # Wyczyść odcisk, by spróbować ponownie
            return False
        else:
            if show_notification and current_fingerprint != last_fingerprint:
                xbmcgui.Dialog().notification("Zalogowano pomyślnie", f"Witaj, {email}", xbmcgui.NOTIFICATION_INFO, 5000)
            ADDON.setSetting('last_login_fingerprint', current_fingerprint) # Zapisz odcisk
            return True

    except Exception:
        ADDON.setSetting('last_login_fingerprint', '')
        xbmcgui.Dialog().notification("Błąd logowania", "Nie można połączyć się z serwisem", xbmcgui.NOTIFICATION_ERROR, 5000)
        return False

def list_channels():
    """Pobiera listę kanałów - używa bardziej niezawodnej metody."""
    try:
        if os.path.exists(FANART_PATH):
            xbmcplugin.setProperty(ADDON_HANDLE, 'Fanart_Image', FANART_PATH)

        channels_page_url = f"{BASE_URL}/pl/channels"
        response = SESSION.get(channels_page_url)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, 'html.parser')
        # ZMIANA: Bardziej niezawodna metoda znajdowania kanałów
        channel_links = soup.select("a[href*='/pl/live/']")

        if not channel_links:
            xbmcgui.Dialog().ok("Błąd", "Nie udało się znaleźć listy kanałów na stronie.")
            return

        added_channels_ids = set()

        for link in channel_links:
            href = link.get('href', '')
            parts = href.split('---')

            if len(parts) == 2:
                name_from_url = parts[0].split('/')[-1]
                channel_id = parts[1]

                if channel_id in added_channels_ids:
                    continue
                added_channels_ids.add(channel_id)
                
                # Znajdź kontener nadrzędny, aby sprawdzić, czy kanał jest premium
                parent_div = link.find_parent('div', class_=re.compile(r'col-'))

                display_name_tag = link.find('h5', class_='card-title')
                display_name = display_name_tag.text.strip() if display_name_tag else name_from_url.replace('-', ' ').title()

                logo_name_base = name_from_url
                img_tag = link.find('img')
                if img_tag and img_tag.get('src'):
                    logo_filename = img_tag.get('src').split('/')[-1]
                    logo_name_base = logo_filename.replace('.png', '')

                if logo_name_base.endswith('-pl'):
                    logo_url = f"https://turbotv.tv/logo/{logo_name_base}.png"
                else:
                    logo_url = f"https://turbotv.tv/logo/{logo_name_base}-pl.png"

                url_params = {'action': 'play', 'name': name_from_url, 'id': channel_id, 'logo_url': logo_url}
                url = f"{sys.argv[0]}?{urlencode(url_params)}"

                li = xbmcgui.ListItem(label=display_name)
                if parent_div and parent_div.find('div', class_='blocked'):
                    li.setInfo('video', {'title': display_name, 'plot': 'Kanał premium - wymaga subskrypcji'})
                else:
                    li.setInfo('video', {'title': display_name})
                    
                li.setProperty('IsPlayable', 'true')
                art = {'icon': logo_url, 'thumb': logo_url, 'fanart': FANART_PATH}
                li.setArt(art)
                xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)

    except Exception as e:
        xbmcgui.Dialog().ok("Błąd", f"Nie udało się pobrać listy kanałów: {e}")

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def get_play_link(name, channel_id):
    # Ta funkcja pozostaje bez zmian
    try:
        channel_page_url = f"{BASE_URL}/pl/live/{name}---{channel_id}"
        response = SESSION.get(channel_page_url)
        response.raise_for_status()

        if "Wykup subskrypcję" in response.text and "player" not in response.text:
            xbmcgui.Dialog().ok("Brak dostępu", "Ten kanał wymaga aktywnej subskrypcji.")
            return None

        token_pattern = re.compile(r'eyJpdiI6[a-zA-Z0-9\/+=-]+')
        match = token_pattern.search(response.text)
        if not match:
            xbmcgui.Dialog().ok("Błąd", "Nie udało się znaleźć tokenu na stronie kanału.")
            return None
        
        token = match.group(0)
        gate_url = f"https://turbotv.tv/play/link/{channel_id}/{token}.m3u8"
        gate_response = SESSION.get(gate_url, allow_redirects=False, headers={'Origin': BASE_URL, 'Referer': channel_page_url})

        if gate_response.status_code == 302 and 'location' in gate_response.headers:
            return gate_response.headers['location']
        else:
            return None
    except Exception:
        return None

def play_video(name, channel_id, logo_url):
    # Ta funkcja pozostaje bez zmian
    progress_dialog = xbmcgui.DialogProgress()
    progress_dialog.create(ADDON.getAddonInfo('name'), f"Pobieranie linku dla {name.replace('-', ' ').title()}...")
    
    stream_url = get_play_link(name, channel_id)
    progress_dialog.close()
    
    if stream_url:
        play_item = xbmcgui.ListItem(path=stream_url)
        art = {'icon': logo_url, 'thumb': logo_url, 'fanart': FANART_PATH}
        play_item.setArt(art)
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=play_item)

def main():
    if not perform_login():
        return # Przerwij, jeśli logowanie się nie powiodło

    args = dict(parse_qsl(sys.argv[2][1:]))
    action = args.get('action')

    if action == 'play':
        play_video(args.get('name'), args.get('id'), args.get('logo_url'))
    else:
        list_channels()

if __name__ == '__main__':
    main()